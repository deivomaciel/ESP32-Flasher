import os
import sys

# Definir o caminho da pasta 'classes'
if getattr(sys, 'frozen', False):  # Verifica se está rodando como executável
    base_path = sys._MEIPASS
else:  # Quando rodando como script Python
    base_path = os.path.dirname(os.path.abspath(__file__))

classes_path = os.path.join(base_path, 'classes')

# Adicionar o caminho da pasta 'classes' ao sys.path para importar as classes
sys.path.insert(0, classes_path)

from classes.Loader import Loader
from utils.clear import clear
from tabulate import tabulate
from dotenv import load_dotenv
from utils.colors import *
import os


RESET = "\033[0m"         # Reseta cor do terminal
BG_WHITE = "\033[47m"     # Define o fundo branco
BG_BLUE = "\033[44m"      # Fundo azul
BLUE = '\033[34m'

load_dotenv()
loader = Loader()

def format_remote_table(data):
    table = tabulate(
        data, 
        headers=["ID", "MAC", "Data/hora"], 
        tablefmt="grid"
    )
    print(table)

def menu():
    clear()
    options = ['1. Gravar firmware', '2. Visualizar remotas gravadas', '3. Gerar planilha', '4. Apagar banco de dados', '5. Selecionar firmware', '0. Sair']

    while True:    
        device = loader.list_devices()
        print(f"\n=== {BLUE}\{RESET}ↃROME ==={RESET}\n")
        if not device:
            print(f'{BRIGHT_RED}Nenhum dispositivo encontrado!{RESET}')

        else:
            device = device[0]
            loader.set_port(device['port'])
            print(f'Dispositivo selecionado: {BRIGHT_BLUE}{device['desc']}{RESET}')
            print(f'Porta selecionada: {BRIGHT_BLUE}{device['port']}{RESET}')
        
        print(f'Fimware: {BRIGHT_BLUE}{loader.show_current_firmware()}{RESET}\n')
        
        for item in options:
            print(item)

        option = input("\nSelecione uma opção: ")

        if option == "1":
            clear()
            if loader.start_load():
                print(f'{BRIGHT_GREEN}Gravação realizada com sucesso!{RESET}')
            else:
                print(f'\n{BRIGHT_RED}Erro ao conectar ao ESP. Tente novamente!{RESET}')
                
        
        elif option == '2':
            clear()
            try:
                remotes = loader.view_remotes()
                print('Remotas\n')
                format_remote_table(remotes)

            except Exception as e:
                print(e)
                print('Erro ao listar remotas!')

        elif option == '3':
            clear()
            loader.generate_sheet()
            print(f'{BRIGHT_GREEN}\nPlanilha gerada com sucesso!{RESET}\n')

        elif option == '4':
            clear()
            print('Digite "deletar" para continuar ')
            print('Digite "cancelar" para cancelar')
            command = input('>> ')
            
            if command.lower() == 'deletar':
                loader.delete_db()
                print('\nBanco de dados deletado com sucesso!')

            elif command.lower() == 'cancelar':
                print('\nOperação cancelada!')
            
            else:
                print('\nInválido. Cancelando operação!')

        elif option == '5':
            clear()
            print('Firmwates:', end='\n\n')
            saved_firmwares = loader.show_saved_firmwares()
            for firmware_index in range(len(saved_firmwares)):
                print(f'{firmware_index}. {BRIGHT_BLUE}{saved_firmwares[firmware_index]}{RESET}')
            
            print()
            try:
                selected_firmware = int(input('Informe o firmware que deseja utilizar: '))
                if selected_firmware > len(saved_firmwares) - 1 or selected_firmware < 0:
                    print('Opção inválida!\n')
                
                else:
                    loader.set_firmware(saved_firmwares[selected_firmware])
                    clear()
                    print(f'Firmware selecionado: {saved_firmwares[selected_firmware]}\n')

            except Exception as e:
                print('Opção inválida!\n')

        elif option == "0":
            print("Saindo...")
            break

        elif option.strip() == "":
            clear()
            continue

        else:
            print("\nOpção inválida! Tente novamente.")
        
        print('Pressione [ENTER] para continuar')
        input()
        clear()

if __name__ == "__main__":
    menu()
