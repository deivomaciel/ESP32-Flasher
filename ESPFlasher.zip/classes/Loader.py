import serial.tools.list_ports as port_list
import subprocess
from .Database import Database
import pandas as pd
from utils.path_resolver import path_resolver
from utils.clear import clear
import os
from os import listdir
from utils.colors import BRIGHT_GREEN, BRIGHT_BLUE, RESET
import sys

boot_path = path_resolver('BOOT')
database = Database('System')
database.create_tables()

class Loader:
    def __init__(self):
        self.__port = None
        self.__current_firmware = None
        self.set_firmware(self.show_saved_firmwares()[0])

    def list_devices(self) -> list:
        ports = port_list.comports()
        if not ports:
            return False
        else:
            total_ports = [ { 'port': port.device, 'desc': port.description } for port in ports ]
            return total_ports

    def get_mac(self, line_output: str) -> str:
        if line_output.startswith('MAC: '):
            return line_output.split('MAC: ')[1].upper()
            
    def show_saved_firmwares(self):
        return listdir('./firmwares')

    def set_firmware(self, firm):
        self.__current_firmware = firm

    def show_current_firmware(self):
        return self.__current_firmware

    def save_mac(self, mac: str) -> None:    
        # Criear nova thread para guardar mac no banco
        database.save_ctd(mac)

    def set_port(self, port: str):
        self.__port = port

    def list_ports():
        ports = port_list.comports()
        print(ports)

    def view_remotes(self):
        return database.get_all_remotes()

    def delete_db(self):
        database.drop_database()
    

    def start_load(self):
        mac = None

        try:
            # python BOOT\tool-esptoolpy\run_esptool.py --port COM29 chip-id

            command = [
                sys.executable,
                f"{boot_path}/tool-esptoolpy/run_esptool.py",
                "--chip", "esp32c3",
                "--port", self.__port,
                "--baud", "460800",
                "--before", "default_reset",
                "--after", "hard-reset",
                "write-flash", "-z",
                "--flash-mode", "dio",
                "--flash-freq", "80m",
                "--flash-size", "4MB",
                "0x0000", f"{boot_path}/bootloader.bin",
                "0x8000", f"{boot_path}/partitions.bin",
                "0xe000", f"{boot_path}/boot_app0.bin",
                "0x10000", f"./firmwares/{self.__current_firmware}"
            ]

            print("Executando:")
            # print(command)

            processo = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )

            for line in processo.stdout:
                # print(line, end="")

                if mac is None:
                    mac = self.get_mac(line)

                if line.startswith("Writing at"):
                    clear()
                    print(f"MAC da remota: {BRIGHT_BLUE}{mac}{RESET}")
                    print(line)

                elif "A fatal error occurred" in line:
                    processo.wait()
                    return False

            codigo = processo.wait()


            if codigo != 0:
                print(f"\nProcesso finalizado com código: {codigo}")
                return False

            if mac is not None:
                saved = database.find_remote_by_mac(mac)

                if not saved:
                    self.save_mac(mac)

            return True

        except Exception as e:
            print(f"Erro ao executar esptool: {e}")
            return False

    
    
    def generate_sheet(self):
        user_dir = os.path.expanduser("~")  # Exemplo: C:\Users\SeuUsuario
        output_path = os.path.join(user_dir, "relatorio.xlsx")

        data = self.view_remotes()
        columns = ['ID', 'MAC', 'Data e Hora']
        dataframe = pd.DataFrame(data, columns=columns)
        dataframe.to_excel(output_path, index=False)
        print(f"Relatório salvo em: {BRIGHT_BLUE}{output_path}{RESET}")


