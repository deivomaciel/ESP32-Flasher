from utils.path_resolver import path_resolver
import sqlite3
import shutil
import os

db_path = path_resolver('database')

class Database:
    def __init__(self, db_name: str) -> None:
        self.db_name = db_name
        self.__connection = sqlite3.connect(f'{db_path}/{self.db_name}.db')
        self.__cursor = self.__connection.cursor()

    def create_tables(self) -> None:
        query = '''
            CREATE TABLE IF NOT EXISTS Remotes (
                id INTEGER NOT NULL PRIMARY KEY,
                mac VARCHAR(17) NOT NULL UNIQUE,
                load_status BOOLENA,
                Timestamp DATETIME DEFAULT (DATETIME('now', '-3 hours')) NOT NULL
            );
        '''
        self.__cursor.execute(query)

    def save_ctd(self, mac: str) -> bool:
        query = f'INSERT INTO Remotes(mac) VALUES ("{mac}")'
        self.__cursor.execute(query)
        self.__connection.commit()

    def find_remote_by_mac(self, mac:str) -> bool:
        query = f'SELECT * FROM Remotes WHERE mac = "{mac}"'
        result = self.__cursor.execute(query)
        return result.fetchone() is not None
        
    def get_all_remotes(self) -> list:
        query = 'SELECT id, mac, Timestamp FROM Remotes'
        result = self.__cursor.execute(query)
        return result.fetchall()
    
    def drop_database(self):
        query = f"DELETE FROM Remotes"
        self.__cursor.execute(query)
        self.__connection.commit()

# database = Database('dev')
# database.create_tables()
# database.save_ctd('dwwdewdewwedwew')
# print(database.get_all_remotes())
# # print((database.find_remote_by_mac('dwedwedew')))